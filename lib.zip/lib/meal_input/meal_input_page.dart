import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'dart:convert';
import '../models/meal.dart';
import '../repositories/enrichir_poids_usuel.dart';
import '../meal_input/meal_input_notifier.dart';
import '../meal_input/meal_input_state.dart';
import '../widget/food_search_field.dart';
import '../widget/create_food_button.dart';
import '../services/date_service.dart';
import '../models/aliment_usuel.dart'; 
import '../services/decomposition_service.dart';
import '../models/proposed_ingredient.dart';
import '../widget/decomposition_review_sheet.dart';
import '../widget/quantity_page.dart';
import '../widget/suggestion_meal_card.dart';
import '../widget/added_food_tile.dart';



class MealInputPage extends ConsumerStatefulWidget {
  final String selectedDate;
  final String mealType;

  const MealInputPage({
    super.key,
    required this.selectedDate,
    this.mealType = "Petit-déjeuner",
  });

  @override
  ConsumerState<MealInputPage> createState() => _MealInputPageState();
}



class _MealInputPageState extends ConsumerState<MealInputPage> {
  final TextEditingController _searchController = TextEditingController();
  final _decompCtrl = TextEditingController();
  final _decompSvc  = DecompositionService();
  final _recentScrollCtrl = ScrollController();
  final _poidsRepo = PoidsUsuelsRepository();
  List<AlimentUsuel> alimentsUsuels = [];



@override
  void initState() {
    super.initState(); 
    // On appelle la méthode de chargement ici
    _loadAlimentsUsuels();
  }

  @override
  void dispose() {
  _searchController.dispose();
  _decompCtrl.dispose(); // ✅ important
  _recentScrollCtrl.dispose();
  super.dispose();
}
  // decomposition des plats en aliments
Future<void> onDecompose() async {
  final description = _decompCtrl.text.trim();
  if (description.isEmpty) {
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Écris d’abord la description du plat.")),
      );
    }
    return;
  }

  try {
    // 1) Appel API
    final data = await _decompSvc.decompose(description);
    final items = (data["ingredients"] as List)
        .map((e) => ProposedIngredient.fromJson(e as Map<String, dynamic>))
        .toList();

    if (!mounted) return;

    // 2) Récupère notifier + type courant depuis Riverpod
    final provider = mealInputProvider((widget.mealType, widget.selectedDate));
    final notifier = ref.read(provider.notifier);
    final selectedMealType = ref.read(provider).selectedMealType; // suit ton Dropdown du haut

    // 3) Ouvre le sheet (on lui passe le notifier)
    final saved = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      builder: (_) => DecompositionReviewSheet(
        items: items,
        mealType: selectedMealType, // "Petit-déjeuner"/"Déjeuner"/...
        notifier: notifier,
      ),
    );

    // 4) Rafraîchir l’UI si on a enregistré
    if (saved == true) {
      ref.invalidate(mealInputProvider((widget.mealType, widget.selectedDate)));
      _decompCtrl.clear();
    }
  } catch (e) {
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Erreur décomposition : $e")),
      );
    }
  }
}



// Ouvre le picker puis appelle le Notifier en passant les valeurs /100 g
Future<void> _showQuantityDialogFromPer100({
  required String name,
  required double kcalPer100,
  required double proteinPer100,
  required double carbsPer100,
  required double fatPer100,
  required MealInputNotifier notifier,
  bool clearSearchAfter = false, // utile quand ça vient de la recherche
}) async {
  // 1) Unités usuelles (repris de _showQuantityDialog)
  final AlimentUsuel? refAliment = _getPoidsUsuel(name);
  final List<UsualUnit> usualUnits = [];
  if (refAliment != null && refAliment.poids > 0) {
    usualUnits.add(UsualUnit(
      label: refAliment.unite,
      gramsPerUnit: refAliment.poids.toDouble(),
    ));
  }

  // 2) Quantité par défaut : 1 unité si dispo, sinon 100 g (identique à avant)
  final double defaultGrams =
      usualUnits.isNotEmpty ? usualUnits.first.gramsPerUnit : (refAliment?.poids.toDouble() ?? 100.0);

  if (!mounted) return;

  // 3) Ouvre ta page quantité existante (identique à avant)
  final resultInGrams = await Navigator.of(context).push<double>(
    MaterialPageRoute(
      fullscreenDialog: true,
      builder: (_) => QuantityPage(
        title: "Quantité pour '$name'",
        unite: 'g',
        defaultValue: defaultGrams,
        usualUnits: usualUnits,
      ),
    ),
  );

  // 4) Ajout → basé sur les valeurs /100 g (nouveau)
  if (resultInGrams != null && mounted) {
    await notifier.addFromPer100(
      name: name,
      kcalPer100: kcalPer100,
      proteinPer100: proteinPer100,
      carbsPer100: carbsPer100,
      fatPer100: fatPer100,
      qty: resultInGrams,
    );

    if (clearSearchAfter) {
      _searchController.clear();
      notifier.clearSearch();
    }
  }
}


Future<void> _loadAlimentsUsuels() async {
    try {
      final String response = await rootBundle.loadString('assets/poids_usuel.json');
      final List<dynamic> data = json.decode(response);
      if (mounted) {
        setState(() {
          alimentsUsuels = data.map((e) => AlimentUsuel.fromJson(e)).toList();
          
        });
      }
    } catch (e) {
      //print("❌ Erreur de chargement de poids_usuel.json: $e");
    }
  }
  @override
  Widget build(BuildContext context) {
    final provider = mealInputProvider((widget.mealType, widget.selectedDate));
    final state = ref.watch(provider);
    final notifier = ref.read(provider.notifier);
   

    return Scaffold(
      appBar: AppBar(title: const Text("Saisie des repas")),
      
      // ✅ On utilise un unique ListView qui gère tout
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          // --- PARTIE HAUTE (FIXE) ---
          Text("Repas pour le ${DateService.formatFrenchShort(state.selectedDate)}", style: Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height: 16),
          DropdownButton<String>(
            value: state.selectedMealType,
            isExpanded: true,
            onChanged: (value) => value != null ? notifier.changeMealType(value) : null,
            items: ["Petit-déjeuner", "Déjeuner", "Dîner", "Collation", "Activité"]
                .map((v) => DropdownMenuItem(value: v, child: Text(v)))
                .toList(),
          ),
          const SizedBox(height: 16),
          // ⬇️⬇️⬇️ AJOUTE ICI LA CARTE DECOMPOSITION
          Card(
            margin: const EdgeInsets.only(bottom: 16),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    "🍽️ Décrire le plat",
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),

                  // Champ de description avec croix pour effacer
                  ValueListenableBuilder<TextEditingValue>(
                    valueListenable: _decompCtrl,
                    builder: (context, value, _) {
                      return TextField(
                        controller: _decompCtrl,
                        minLines: 1,
                        maxLines: 3,
                        decoration: InputDecoration(
                          hintText: "ex. bol de chili con carne avec riz",
                          border: const OutlineInputBorder(),
                          // 2. On utilise 'value.text' qui vient du builder pour afficher/cacher l'icône
                          suffixIcon: value.text.isNotEmpty
                              ? IconButton(
                                  icon: const Icon(Icons.clear),
                                  onPressed: () => _decompCtrl.clear(), // Plus besoin de setState ici
                                )
                              : null,
                        ),
                        // 3. On supprime complètement le onChanged qui appelait setState
                        onSubmitted: (_) => onDecompose(),
                      );
                    },
                  ),

                  const SizedBox(height: 8),
                  Row(
                    children: [
                      ElevatedButton.icon(
                        onPressed: onDecompose,
                        icon: const Icon(Icons.auto_awesome),
                        label: const Text("Décomposer"),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),

  // ⬆️⬆️⬆️ FIN DU BLOC DECOMPOSITION
          // 🔎 Recherche d’aliments harmonisée
Card(
  margin: const EdgeInsets.only(bottom: 16),
  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
  child: Padding(
    padding: const EdgeInsets.all(12),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          "🔎 Rechercher un aliment",
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 8),

        FoodSearchField(
          controller: _searchController,
          onChanged: (value) => notifier.searchFood(value),
          onClear: () {
            _searchController.clear();
            notifier.clearSearch();
            
          },
        ),
      ],
    ),
  ),
),

          const SizedBox(height: 16),

          // --- PARTIE CENTRALE (SUGGESTIONS / RÉSULTATS) ---
          // On utilise l'opérateur "..." pour insérer la liste de widgets directement
          ..._buildSuggestionsOrResults(state, notifier),

          const SizedBox(height: 24),
          const Divider(),
          const SizedBox(height: 24),

          // --- PARTIE BASSE (ALIMENTS AJOUTÉS) ---
          _buildAddedFoodsSection(
              context,
              meals: state.addedFoodsForDay,
              onRemove: (meal) => notifier.removeFood(meal),
              onQtyChange: (meal, q) => notifier.updateFoodQuantity(meal, q),
              alimentsUsuels: alimentsUsuels,
            ),
        ],
      ),
    );
  }

  // ✅ Ces méthodes retournent maintenant des List<Widget>
  List<Widget> _buildSuggestionsOrResults(MealInputState state, MealInputNotifier notifier) {
    if (state.status == SearchStatus.loading) {
      return [const Center(child: CircularProgressIndicator())];
    }
    if (_searchController.text.length > 2) {
      if (state.searchSuggestions.isEmpty) {
        return [
              Card(
                elevation: 3,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  // ✅ ON REMPLACE LE WRAP PAR UN ROW
                  child: Row(
                    children: [
                      // ✅ On enveloppe chaque bouton dans un Expanded
                      Expanded(
                        child: CreateFoodButton(
                          label: "Créer", // Un label plus court pour les petits écrans
                          color: Colors.orange,
                          nameSuggestion: _searchController.text,
                          onPressed: (context, suggestion) => _showCreateFoodDialog(notifier),
                        ),
                      ),
                      const SizedBox(width: 12), // Espace entre les boutons
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: state.status == SearchStatus.loading
                              ? null
                              : () => notifier.searchFood(_searchController.text),
                          icon: state.status == SearchStatus.loading
                              ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                              : const Icon(Icons.cloud_download),
                          label: const Text("Internet"), // Un label plus court
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.blue,
                            foregroundColor: Colors.white,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              )
        ];    
      }
      return _buildSearchResults(state.searchSuggestions, notifier);
    }
    return _buildrecentSuggestions(state.recentSuggestions, notifier);
  }

  List<Widget> _buildrecentSuggestions(
  List<Meal> suggestions,
  MealInputNotifier notifier,
) {
  final theme = Theme.of(context);
  final cs = theme.colorScheme;

  final filtered = _filterSuggestions(suggestions);

  if (filtered.isEmpty) {
    return [
      Card(
        elevation: 1,
        color: cs.surfaceContainerHigh,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        child: const Padding(
          padding: EdgeInsets.all(12),
          child: Text("Aucune suggestion pertinente pour l’instant."),
        ),
      ),
    ];
  }

  return [
    Card(
      elevation: 1,
      color: cs.surfaceContainerHigh,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(10, 10, 10, 6),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              const Icon(Icons.lightbulb, size: 16),
              const SizedBox(width: 6),
              Text("Mes aliments récents", style: theme.textTheme.titleSmall),
            ]),
            const SizedBox(height: 8),
    //**************** */
           

            ConstrainedBox(
              constraints: BoxConstraints(
                maxHeight: (theme.textTheme.bodyMedium?.fontSize ?? 14) *
                          (theme.textTheme.bodyMedium?.height ?? 1.2) *
                          15, // 🔹 15 lignes
              ),
              child: Scrollbar(
                controller: _recentScrollCtrl,
                thumbVisibility: true,
                child: ListView.separated(
                  controller: _recentScrollCtrl,
                  padding: EdgeInsets.zero,
                  primary: false,
                  itemCount: filtered.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 6),
                  itemBuilder: (context, i) {
                    final meal = filtered[i];
                    return SuggestionMealCard(
                      meal: meal,
                      // ✅ toujours /100 g via les getters robustes
                      kcalPer100: meal.kcalPer100X,
                      proteinPer100: meal.proteinPer100X,
                      carbsPer100: meal.carbsPer100X,
                      fatPer100: meal.fatPer100X,
                      onAdd: () => _showQuantityDialogFromPer100(
                        name: meal.name,
                        kcalPer100: meal.kcalPer100X,
                        proteinPer100: meal.proteinPer100X,
                        carbsPer100: meal.carbsPer100X,
                        fatPer100: meal.fatPer100X,
                        notifier: notifier,
                      ),
                    );

                  },
                ),
              ),
            )



  //**************** */
          ],
        ),
      ),
    ),
  ];
}



// résultat de la recherche
  List<Widget> _buildSearchResults(List<dynamic> suggestions, MealInputNotifier notifier) {
     if (suggestions.isEmpty) return [const Center(child: Text("Aucun résultat."))];
     return [
      Text("Résultats de la recherche", style: Theme.of(context).textTheme.titleLarge),
      ...suggestions.map((foodData) {
          final name = foodData['product_name'] as String? ?? 'Nom inconnu';
          final source = (foodData['source'] as String?) ?? 'api';
          final isCustom = foodData['isCustom'] == true;
          final nutriments = foodData['nutriments'] as Map<String, dynamic>? ?? {};
          final calories = nutriments['energy-kcal_100g'] as num? ?? 0.0;
          return ListTile(
            leading: isCustom ? const Icon(Icons.star, color: Colors.amber) : null,
            title: Text(name),
            subtitle: Text("${calories.toStringAsFixed(0)} kcal / 100g • ${source.toUpperCase()}"),
            trailing: const Icon(Icons.add_circle_outline),
            onTap: () {
              _showQuantityDialog(foodData, notifier);
            },
          );
        }),
     ];
     
  }
  

String _normalize(String s) {
  final lower = s.trim().toLowerCase();
  // Supprime grossièrement les accents (remplacements courants)
  const repl = {
    'à':'a','á':'a','â':'a','ä':'a','ã':'a','å':'a',
    'ç':'c',
    'è':'e','é':'e','ê':'e','ë':'e',
    'ì':'i','í':'i','î':'i','ï':'i',
    'ñ':'n',
    'ò':'o','ó':'o','ô':'o','ö':'o','õ':'o',
    'ù':'u','ú':'u','û':'u','ü':'u',
    'ÿ':'y'
  };
  final sb = StringBuffer();
  for (final ch in lower.characters) {
    sb.write(repl[ch] ?? ch);
  }
  return sb.toString().replaceAll(RegExp(r'\s+'), ' ');
}

List<String> _tokens(String s) {
  return _normalize(s)
      .split(RegExp(r'[^a-z0-9%]+'))        // garde chiffres (200g) et %
      .where((w) => w.isNotEmpty && w.length > 1) // ignore tokens 1 lettre
      .toList();
}

bool _wordBoundaryContains(String haystack, String needle) {
  // recherche du needle en tant que mot entier (limites \b)
  final re = RegExp(r'\b' + RegExp.escape(needle) + r'\b');
  return re.hasMatch(haystack);
}

double _coverageScore({
  required List<String> nameWords,
  required List<String> keyWords,
  required String nameNorm,
}) {
  if (keyWords.isEmpty) return 0;
  int hits = 0;
  for (final w in keyWords) {
    if (_wordBoundaryContains(nameNorm, w)) hits++;
  }
  final cov = hits / keyWords.length; // 0..1
  return cov;
}

AlimentUsuel? _getPoidsUsuel(String nom) {
  final rawName   = nom.trim();
  if (rawName.isEmpty || alimentsUsuels.isEmpty) return null;

  final nameNorm  = _normalize(rawName);
  final nameWords = _tokens(rawName);
  if (nameWords.isEmpty) return null;

  AlimentUsuel? best;
  int bestScore = -1;

  for (final a in alimentsUsuels) {
    final keyRaw   = a.aliment.trim();
    if (keyRaw.isEmpty) continue;

    final keyNorm  = _normalize(keyRaw);
    final keyWords = _tokens(keyRaw);
    if (keyWords.isEmpty) continue;

    int score = 0;

    // 1) Match exact (après normalisation)
    if (nameNorm == keyNorm) {
      score = 3000;
    } else {
      // 2) Égalité d’ensemble de mots (ordre indifférent)
      final setName = nameWords.toSet();
      final setKey  = keyWords.toSet();
      final sameSet = setName.length == setKey.length &&
                      setName.containsAll(setKey);
      if (sameSet) {
        score = 2400 + keyWords.length; // léger bonus longueur
      }

      // 3) Couverture forte avec bornes de mots
      if (score == 0) {
        final cov = _coverageScore(
          nameWords: nameWords, keyWords: keyWords, nameNorm: nameNorm,
        ); // 0..1
        if (cov >= 0.9) {
          score = 2000 + keyWords.length;        // quasi-équivalent
        } else if (cov >= 0.7) {
          score = 1500 + (cov * 100).round();    // assez proche
        }
      }

      // 4) Secours: préfixe strict si le keyword est MONO-mot
      if (score == 0 && keyWords.length == 1) {
        final k = keyWords.first;
        if (nameNorm.startsWith(k + ' ') || nameNorm == k) {
          score = 900;
        }
      }
    }

    if (score > bestScore) {
      bestScore = score;
      best = a;
    }
  }

  // Seuil minimal pour éviter les faux positifs
  if (best != null && bestScore >= 1200) {
    return best;
  }

  // Rien d’assez fiable → enregistrer le “missing”
  _poidsRepo.addMissingIfNeeded(rawName);
  return null;
}



Future<void> _showQuantityDialog(dynamic foodData, MealInputNotifier notifier) async {
  final String name = foodData is Meal
      ? foodData.name
      : ((foodData['name'] ?? foodData['product_name']) as String? ?? 'Aliment');

  // 1) Récupère une unité/usuel si dispo
  final AlimentUsuel? refAliment = _getPoidsUsuel(name);
  final List<UsualUnit> usualUnits = [];
  if (refAliment != null && refAliment.poids > 0) {
    usualUnits.add(UsualUnit(
      label: refAliment.unite,
      gramsPerUnit: refAliment.poids.toDouble(),
    ));
  }

  // 2) Valeur par défaut : 1 unité si dispo, sinon 100 g
  final double defaultGrams =
      usualUnits.isNotEmpty ? usualUnits.first.gramsPerUnit : (refAliment?.poids.toDouble() ?? 100.0);

  if (!mounted) return;

  // 3) Ouvre la page quantité
  final resultInGrams = await Navigator.of(context).push<double>(
    MaterialPageRoute(
      fullscreenDialog: true,
      builder: (_) => QuantityPage(
        title: "Quantité pour '$name'",
        unite: 'g',
        defaultValue: defaultGrams,
        usualUnits: usualUnits,
      ),
    ),
  );

  // 4) Ajout (normalisation /100 g gérée dans MealInputNotifier.addFood)
  if (resultInGrams != null && mounted) {
    await notifier.addFood(foodData, resultInGrams);

    // Nettoyage de la recherche
    _searchController.clear();
    notifier.clearSearch();
  }
}





  /// Affiche le dialogue pour créer un nouvel aliment
  Future<void> _showCreateFoodDialog(MealInputNotifier notifier) async {
    // ✅ On ajoute une GlobalKey pour la validation du formulaire
    final formKey = GlobalKey<FormState>(); 
    // On crée des controllers pour chaque champ du formulaire
    final nameController = TextEditingController(text: _searchController.text);
    final calController = TextEditingController();
    final protController = TextEditingController();
    final carbController = TextEditingController();
    final fatController = TextEditingController();
    final qtyController = TextEditingController(text: "100");

    if (!mounted) return;

    await showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text("Créer un nouvel aliment"),
        // Le SingleChildScrollView évite les erreurs de dépassement quand le clavier apparaît
        content: SingleChildScrollView(
          child: Form(
          key: formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextFormField( // ✅ On utilise un TextFormField pour la validation
                controller: nameController,
                decoration: const InputDecoration(labelText: "Nom"),
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'Le nom est obligatoire.';
                  }
                  return null;
                },
                autofocus: true,
              ),
                TextField(controller: calController, decoration: const InputDecoration(labelText: "Calories / 100g"), keyboardType: TextInputType.number),
                TextField(controller: protController, decoration: const InputDecoration(labelText: "Protéines / 100g"), keyboardType: TextInputType.number),
                TextField(controller: carbController, decoration: const InputDecoration(labelText: "Glucides / 100g"), keyboardType: TextInputType.number),
                TextField(controller: fatController, decoration: const InputDecoration(labelText: "Lipides / 100g"), keyboardType: TextInputType.number),
                TextField(controller: qtyController, decoration: const InputDecoration(labelText: "Quantité consommée (g)"), keyboardType: TextInputType.number),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text("Annuler")),
          ElevatedButton(
            onPressed: () async {
              // On appelle la méthode du Notifier pour créer et ajouter le repas
              if (formKey.currentState!.validate()) {
              await notifier.createAndAddFood(
                name: nameController.text,
                calories: double.tryParse(calController.text) ?? 0,
                protein: double.tryParse(protController.text) ?? 0,
                carbs: double.tryParse(carbController.text) ?? 0,
                fat: double.tryParse(fatController.text) ?? 0,
                quantity: double.tryParse(qtyController.text) ?? 100,
              );

              // On nettoie la recherche et on ferme la pop-up
              _searchController.clear();
              notifier.clearSearch();
              if (mounted) Navigator.of(context).pop();
             }
            },
            child: const Text("Créer et Ajouter"),
          ),
        ],
      ),
    );
  }
}













// ⚠️ Conserve l'ordre d'entrée (donc la récence) et coupe à 15.
List<Meal> _filterSuggestions(List<Meal> items) {
  // 1) nettoie / filtre les fiches incohérentes
  final cleaned = items.where((m) {
    final name = (m.name).trim();
    final kcal = m.calories;
    final p    = m.protein;
    final g    = m.carbs;
    final l    = m.fat;

    if (name.isEmpty) return false;
    if (!kcal.isFinite || kcal <= 0) return false; // exclut 0 kcal
    if (kcal > 1200) return false;                 // borne haute réaliste (≈/100g)
    if (p < 0 || g < 0 || l < 0 || p > 100 || g > 100 || l > 100) return false;
    if (p == 0 && g == 0 && l == 0) return false;  // évite fiches vides
    return true;
  });

  // 2) dédoublonne par nom "normalisé" en CONSERVANT le 1er (donc le plus récent)
  final seen = <String>{};
  final dedup = <Meal>[];
  for (final m in cleaned) {
    final key = _normalizeKey(m.name);
    if (seen.add(key)) dedup.add(m);
  }

  // 3) ❌ pas de tri → on garde l’ordre d’arrivée (récence) ; et on coupe à 15
  return dedup.take(15).toList();
}

// Helper robuste pour dédoublonner intelligemment
String _normalizeKey(String s) {
  var t = s.trim().toLowerCase();

  // enlève accents
  const withAccents = 'àâäáãåçéèêëíìîïñóòôöõúùûüŷýÿœæ';
  const noAccents   = 'aaaaaaceeeeiiiinooooouuuuyyyoeae';
  for (var i = 0; i < withAccents.length; i++) {
    t = t.replaceAll(withAccents[i], noAccents[i]);
  }

  // supprime ponctuation/espaces multiples
  t = t.replaceAll(RegExp(r'[^\w\s]'), ' ').replaceAll(RegExp(r'\s+'), ' ');

  // singularise très léger (banal) – optionnel
  t = t.replaceAll(RegExp(r's\b'), '');

  return t;
}


Widget _buildAddedFoodsSection(
  BuildContext context, {
    required List<Meal> meals,
    required void Function(Meal meal) onRemove,
    required void Function(Meal meal, double newQty) onQtyChange,
    required List<AlimentUsuel> alimentsUsuels,
  }) {
  final theme = Theme.of(context);
  final cs = theme.colorScheme;
  

  return Card(
    elevation: 1,
    color: cs.surfaceContainerHigh,
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
    child: Padding(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            const Icon(Icons.checklist, size: 18),
            const SizedBox(width: 6),
            Text("Aliments ajoutés", style: theme.textTheme.titleSmall),
          ]),
          const SizedBox(height: 8),

          if (meals.isEmpty)
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(
                "Aucun aliment ajouté pour ce repas.",
                style: theme.textTheme.bodyMedium?.copyWith(color: cs.onSurfaceVariant),
              ),
            )
          else
            ListView.separated(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: meals.length,
              separatorBuilder: (_, __) => const SizedBox(height: 8),
              itemBuilder: (ctx, i) {
                final m = meals[i];
                final refAl = poidsUsuelForName(alimentsUsuels, m.name);
                final double? step  = refAl?.poids.toDouble(); // ex. 12.0 g par "morceau"
                final String? label = refAl?.unite; 
                
                return Dismissible(
                  //key: ValueKey("${m.name}-${m.quantity}-$i"),
                  key: ValueKey(
                    m.firestoreId ?? m.key ?? '${m.name}-${m.date}-${m.type}',
                  ),
                  direction: DismissDirection.endToStart,
                  background: Container(
                    alignment: Alignment.centerRight,
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    decoration: BoxDecoration(
                      color: Colors.red,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Icon(Icons.delete, color: Colors.white),
                  ),
                  onDismissed: (_) => onRemove(m),
                  child: AddedFoodTile(
                    meal: m,
                    onRemove: () => onRemove(m),
                    onQtyChange: (q) => onQtyChange(m, q),
                    unitStepGrams: step,
                    unitLabel: label,
                  ),
                );
              },
            ),

          if (meals.isNotEmpty) ...[
            const SizedBox(height: 10),
            TotalsBar(
              calories: meals.fold<double>(0.0, (a, m) => a + m.calories),
              prot:     meals.fold<double>(0.0, (a, m) => a + m.protein),
              carbs:    meals.fold<double>(0.0, (a, m) => a + m.carbs),
              fat:      meals.fold<double>(0.0, (a, m) => a + m.fat),
            ),
          ],
        ],
      ),
    ),
  );
}



AlimentUsuel? poidsUsuelForName(List<AlimentUsuel> base, String nom) {
      final lowerName = nom.trim().toLowerCase();
      if (base.isEmpty) return null;

      // Passe 1 : exact
      for (var a in base) {
        if (lowerName == a.aliment.trim().toLowerCase()) return a;
      }

      // Passe 2 : premier mot
      final firstWord = lowerName.split(' ').first;
      if (firstWord.isNotEmpty && firstWord != lowerName) {
        for (var a in base) {
          if (firstWord == a.aliment.trim().toLowerCase()) return a;
        }
      }

      // Passe 3 : meilleure partielle
      AlimentUsuel? best;
      int bestIndex = -1;
      for (var a in base) {
        final keyword = a.aliment.trim().toLowerCase();
        if (keyword.isNotEmpty && lowerName.contains(keyword)) {
          final idx = lowerName.indexOf(keyword);
          if (best == null || idx < bestIndex) {
            best = a; bestIndex = idx;
          }
        }
      }
      return best;
    }
