import 'package:hive/hive.dart';

part 'meal.g.dart';

/// Parse sûr → double (gère num, string "12,3", null)
double _parseDouble(dynamic v) {
  if (v == null) return 0.0;
  if (v is num) return v.toDouble();
  return double.tryParse(v.toString().replaceAll(',', '.')) ?? 0.0;
}

/// Parse optionnel → double? (retourne null si non convertible)
double? _parseDoubleOpt(dynamic v) {
  if (v == null) return null;
  if (v is num) return v.toDouble();
  return double.tryParse(v.toString().replaceAll(',', '.'));
}

@HiveType(typeId: 0)
class Meal extends HiveObject {
  // ⚠️ Garde EXACTEMENT ces indices déjà utilisés dans ta base
  @HiveField(0)
  String name;

  @HiveField(1)
  double calories;

  @HiveField(2)
  double protein;

  @HiveField(3)
  double carbs;

  @HiveField(4)
  double fat;

  @HiveField(5)
double quantity;

@HiveField(6)
String type;

@HiveField(7)
String date;

  @HiveField(8)
  String? firestoreId;

  // --- Nouveaux champs /100 g (indices libres ajoutés) ---
  @HiveField(50)
  double? kcalPer100;

  @HiveField(51)
  double? proteinPer100;

  @HiveField(52)
  double? carbsPer100;

  @HiveField(53)
  double? fatPer100;

  Meal({
    required this.name,
    required this.calories,
    required this.protein,
    required this.carbs,
    required this.fat,
    required this.type,
    required this.date,
    this.quantity = 100.0,
    this.firestoreId,
    this.kcalPer100,
    this.proteinPer100,
    this.carbsPer100,
    this.fatPer100,
  });

  /// fromMap robuste (Firestore / API)
  factory Meal.fromMap(Map<String, dynamic> map, {String? id}) {
    final nutr = map['nutriments'] as Map<String, dynamic>? ?? const {};

    // Nom : product_name > name > défaut
    String name = ((map['product_name'] ?? map['name']) as String?)?.trim() ?? '';
    if (name.isEmpty) name = 'Aliment sans nom';

    // kcal: plusieurs clés possibles ; fallback kJ → kcal
    double kcal = _parseDouble(nutr['energy-kcal_100g'] ?? map['calories']);
    if (kcal == 0.0) {
      final kj = _parseDouble(nutr['energy-kj_100g'] ?? map['energy-kj_100g'] ?? nutr['energy_100g'] ?? map['energy_100g']);
      if (kj > 0) kcal = kj / 4.184;
    }

    return Meal(
      name: name,
      calories: kcal,
      protein:  _parseDouble(nutr['proteins_100g'] ?? map['protein']),
      carbs:    _parseDouble(nutr['carbohydrates_100g'] ?? map['carbs']),
      fat:      _parseDouble(nutr['fat_100g'] ?? map['fat']),
      quantity: _parseDouble(map['quantity']),
      // champs /100 g si déjà présents côté Firestore
      kcalPer100:     _parseDoubleOpt(map['kcalPer100']),
      proteinPer100:  _parseDoubleOpt(map['proteinPer100']),
      carbsPer100:    _parseDoubleOpt(map['carbsPer100']),
      fatPer100:      _parseDoubleOpt(map['fatPer100']),
      // strings
      type: (map['type'] as String?) ?? '',
      date: (map['date'] as String?) ?? '',
      firestoreId: id ?? map['firestoreId'] as String?,
    );
    
  }

  /// toMap → sérialisation Firestore
  Map<String, dynamic> toMap() {
  return {
    'name': name,
    'calories': calories,     // totaux pour la qty
    'protein': protein,
    'carbs': carbs,
    'fat': fat,
    'quantity': quantity,     // en grammes
    'type': type,
    'date': date,
    if (firestoreId != null) 'firestoreId': firestoreId,

    // ✅ champs /100 g
    'kcalPer100': kcalPer100,
    'proteinPer100': proteinPer100,
    'carbsPer100': carbsPer100,
    'fatPer100': fatPer100,
  };
}

}


/// Getters affichage : garantissent des valeurs **/100 g**
extension MealPer100X on Meal {
  double get kcalPer100X =>
      (kcalPer100 != null && kcalPer100! > 0)
          ? kcalPer100!
          : (quantity > 0 ? (calories * 100.0) / quantity : 0.0);

  double get proteinPer100X =>
      (proteinPer100 != null && proteinPer100! > 0)
          ? proteinPer100!
          : (quantity > 0 ? (protein * 100.0) / quantity : 0.0);

  double get carbsPer100X =>
      (carbsPer100 != null && carbsPer100! > 0)
          ? carbsPer100!
          : (quantity > 0 ? (carbs * 100.0) / quantity : 0.0);

  double get fatPer100X =>
      (fatPer100 != null && fatPer100! > 0)
          ? fatPer100!
          : (quantity > 0 ? (fat * 100.0) / quantity : 0.0);
}


